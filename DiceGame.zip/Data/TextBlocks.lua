local TextBlocks = {}

TextBlocks.introLore = "It's the annual insect contest!\nGrab your dice and show em'\nwho's the best beetle around!"

TextBlocks.dicePacks = "Before your next match you have\na chance for some new options!"

TextBlocks.diceBreak = "Dice can have special\npowers, lets break one open!"

TextBlocks.victory = "Victory. You defeated all the\nenemies and earned your spots!"

return TextBlocks
