local ScreenOrder = {
	IntroScreen,
	GameScreen, -- 2, Mantis
	DicePackScreen,
	GameScreen, -- 4, Moth
	DiceBreakScreen,
	GameScreen, -- 6, Beetle
	DicePackScreen,
	GameScreen, -- 8, Centipede
	DicePackScreen,
	DiceBreakScreen,
	GameScreen, -- 11, LadyBeetle
	VictoryScreen
}

return ScreenOrder
